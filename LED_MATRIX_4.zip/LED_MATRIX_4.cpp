#include "LED_MATRIX_4.h"

LED_MATRIX_4::LED_MATRIX_4(int _DIN, int _CLK, int _CS) {
  DIN = _DIN;
  CLK = _CLK;
  CS = _CS;
}

void LED_MATRIX_4::begin() {
  int devices = lc.getDeviceCount();
  if (devices != 4) {
    // #error "Number of Devices is not 4. Please Verify"
  }
  for (int address = 0; address < devices; address++) {
    lc.shutdown(address, false);
    lc.setIntensity(address, 8);
    lc.clearDisplay(address);
  }
}


void LED_MATRIX_4::drawDigit(int digit, int matrix) {
  lc.clearDisplay(matrix);
  for (int row = 0; row < 8; row++) {
    lc.setRow(matrix, row, digitFont8x8[digit][row]);
  }
}

int LED_MATRIX_4::getLetterPos(char Letter) {
  Letter = Letter - 'A';
  return (Letter);
}

void LED_MATRIX_4::drawNumber(int num) {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    delay(10);
  }
  int tens = (num / 10) % 10;
  int ones = num % 10;
  int hundreds = (num / 100) % 10;
  int thousands = (num / 1000) % 10;
  if (num < 10) {
    drawDigit(ones, 3);
  } else if (num >= 10 && num < 100) {
    drawDigit(ones, 2);
    drawDigit(tens, 3);
  } else if (num >= 100 && num < 1000) {
    drawDigit(ones, 1);
    drawDigit(tens, 2);
    drawDigit(hundreds, 3);
  } else if (num >= 1000) {
    drawDigit(ones, 0);
    drawDigit(tens, 1);
    drawDigit(hundreds, 2);
    drawDigit(thousands, 3);
  }
}

void LED_MATRIX_4::drawLetter(char letter, int matrix) {
  lc.clearDisplay(matrix);
  for (int row = 0; row < 8; row++) {
    lc.setRow(matrix, row, Alphabet[letter][row]);
  }
}

void LED_MATRIX_4::draw_Word(char Word[4]) {
  for (int i = 3; i >= 0; i--) {
    lc.clearDisplay(i);
    drawLetter(getLetterPos(Word[i]), i);
  }
}

void LED_MATRIX_4::draw_RedLight() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, Redlight[row]);
    }
  }
}

void LED_MATRIX_4::draw_Crosses() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, fail[row]);
    }
  }
}

void LED_MATRIX_4::draw_word_TIME() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, TIME[i][row]);
    }
  }
}


void LED_MATRIX_4::draw_word_LOSE() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, LOSE[i][row]);
    }
  }
}

void LED_MATRIX_4::draw_word_FREE() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, FREE[i][row]);
    }
  }
}

void LED_MATRIX_4::draw_word_RANK() {
  for (int i = 0; i < 4; i++) {
    lc.clearDisplay(i);
    for (int row = 0; row < 8; row++) {
      lc.setRow(i, row, RANK[i][row]);
    }
  }
}
